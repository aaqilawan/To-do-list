//Selector
const todoList = document.querySelector(".todo-list");
const todoInput = document.querySelector(".todo-input");
const todoBtn = document.querySelector(".todo-btn");
const filteroption = document.querySelector('.filter-todo');

//Events
todoBtn.addEventListener('click', createTodo);
todoList.addEventListener('click', deleter_check);
filteroption.addEventListener('click', filterToDo);
document.addEventListener('DOMContentLoaded',getStorage);


//Function
function createTodo(event) {
    event.preventDefault();
    // create div
    const main = document.createElement('div');
    main.classList.add('main-todo');
    // create li
    const li = document.createElement('li');
    li.classList.add('todo-item');
    li.innerText = todoInput.value;
    main.appendChild(li);
    saveStorage(todoInput.value);
    // create check button
    const complete = document.createElement('button');
    complete.classList.add('todo-complete');
    complete.innerHTML = '<i class="fas fa-check-square"></i>';
    main.appendChild(complete);
    // create delete button
    const trash = document.createElement('button');
    trash.classList.add('todo-trash');
    trash.innerHTML = '<i class="fas fa-trash"></i>';
    main.appendChild(trash);

    todoList.appendChild(main);

    todoInput.value = "";

}

function deleter_check(e) {
    //delete
    const item = e.target;
    if (item.classList[0] === 'todo-trash') {
        const todo = item.parentElement;
        todo.classList.add('naim');
        removeStorage(todo);
        todo.addEventListener('transitionend', () => {
            todo.remove();
        })

    }
    //check
    if (item.classList[0] === 'todo-complete') {
        const todo = item.parentElement;
        todo.classList.toggle('completed')
    }

}
// filterable
function filterToDo(event) {

    const todos = todoList.childNodes;
   
    todos.forEach(function (todo) {
        if (todo.nodeName === '#text') {
            // do nothing
        } else {
            switch (event.target.value) {
                case "all":
                    todo.style.display = 'flex';
                    break;
                case "completed":
                    if (todo.classList.contains('completed')) {
                        todo.style.display = 'flex';
                    } else {
                        todo.style.display = 'none';
                    }
                    break;
                case "uncompleted":
                    if (!todo.classList.contains('completed')) {
                        todo.style.display = 'flex';
                    } else {
                        todo.style.display = 'none';
                    }
                    break;
            }
        }
    });
}

//localStorage area 
// Save into the localstragae data
function saveStorage(todo){
    let todoes;
    if(localStorage.getItem('todoes') === null){
        todoes = [];
    }
    else{
        todoes = JSON.parse(localStorage.getItem("todoes"))
    }
    todoes.push(todo);
    localStorage.setItem("todoes",JSON.stringify(todoes));   
}
//Save consistent data in the brower
function getStorage(){
    let todoes;
    if(localStorage.getItem('todoes') === null){
        todoes = [];
    }
    else{
        todoes = JSON.parse(localStorage.getItem("todoes"))
    }

    todoes.forEach(function(todo){
         // create div
    const main = document.createElement('div');
    main.classList.add('main-todo');
    // create li
    const li = document.createElement('li');
    li.classList.add('todo-item');
    li.innerText = todo;
    main.appendChild(li);
    // create check button
    const complete = document.createElement('button');
    complete.classList.add('todo-complete');
    complete.innerHTML = '<i class="fas fa-check-square"></i>';
    main.appendChild(complete);
    // create delete button
    const trash = document.createElement('button');
    trash.classList.add('todo-trash');
    trash.innerHTML = '<i class="fas fa-trash"></i>';
    main.appendChild(trash);

    todoList.appendChild(main);
    })
}
function removeStorage(todo){
    let todoes;
    if(localStorage.getItem('todoes') === null){
        todoes = [];
    }
    else{
        todoes = JSON.parse(localStorage.getItem("todoes"))
    }

    let todoIndex = todo.children[0].innerHTML;
    todoes.splice(todoes.indexOf(todoIndex),1);
    localStorage.setItem("todoes",JSON.stringify(todoes));   
}